import 'package:flutter/material.dart';

void main() {
  runApp(QuizApp());
}

class QuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kuis Informatika',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.lightBlue[50],
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blueAccent,
            foregroundColor: Colors.white,
            textStyle: TextStyle(fontSize: 16),
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ),
      home: QuizHomePage(),
    );
  }
}

class QuizHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Kuis Mahasiswa Baru",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.quiz, size: 100, color: Colors.blue[700]),
              SizedBox(height: 30),
              Text(
                "Selamat datang di Kuis Manajemen Informatika!",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 10),
              Text(
                "Uji pengetahuanmu dalam bidang Manajemen Informatika!",
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 30),
              ElevatedButton.icon(
                icon: Icon(Icons.play_arrow),
                label: Text("Mulai Kuis"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => QuizPage()),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int _currentQuestionIndex = 0;
  int _score = 0;
  List<String> _selectedAnswers = [];

  final List<Map<String, dynamic>> _questions = [
    {
      'question': "Apa kepanjangan dari SQL?",
      'options': ["Structured Query Language", "Simple Query Logic", "Standard Query List", "System Query Language"],
      'answer': "Structured Query Language"
    },
    {
      'question': "Apa fungsi utama dari database?",
      'options': ["Mengolah data", "Menyimpan dan mengelola data", "Membuat desain UI", "Menjalankan program"],
      'answer': "Menyimpan dan mengelola data"
    },
    {
      'question': "Apa itu API?",
      'options': ["Application Programming Interface", "Automated Process Integration", "Advanced Programming Index", "All Process Interaction"],
      'answer': "Application Programming Interface"
    },
    {
      'question': "Bahasa pemrograman yang sering digunakan untuk pengembangan aplikasi Android adalah?",
      'options': ["Python", "Java", "C++", "Ruby"],
      'answer': "Java"
    },
    {
      'question': "Apa kepanjangan dari HTTP?",
      'options': ["HyperText Transfer Protocol", "High Tech Transmission Process", "Hyperlink Transfer Program", "High Transfer Text Protocol"],
      'answer': "HyperText Transfer Protocol"
    },
    {
      'question': "Apa yang menjadi fokus utama dari Program Studi Manajemen Informatika?",
      'options': [
        "Pemrograman tingkat lanjut dan pengolahan sinyal digital",
        "Pengelolaan sistem informasi dan penerapan teknologi dalam bisnis",
        "Analisis struktur data dan algoritma",
        "Rancang bangun jaringan komputer skala besar"
      ],
      'answer': "Pengelolaan sistem informasi dan penerapan teknologi dalam bisnis"
    },
    {
      'question': "Salah satu keterampilan utama yang akan dipelajari di Manajemen Informatika adalah...",
      'options': [
        "Teknik pertambangan data mentah",
        "Pembuatan animasi 3D untuk film",
        "Pengelolaan basis data dan sistem informasi",
        "Perancangan robot otomatis"
      ],
      'answer': "Pengelolaan basis data dan sistem informasi"
    },
    {
      'question': "Tools berikut ini sering digunakan untuk membuat antarmuka aplikasi berbasis web, KECUALI:",
      'options': ["HTML", "CSS", "JavaScript", "AutoCAD"],
      'answer': "AutoCAD"
    },
    {
      'question': "Untuk membuat dan mengelola basis data, tools yang paling umum digunakan di lingkungan Manajemen Informatika adalah...",
      'options': ["Photoshop", "MySQL", "Blender", "CorelDRAW"],
      'answer': "MySQL"
    },
    {
      'question': "Salah satu prospek kerja lulusan Manajemen Informatika adalah...",
      'options': ["Ahli Geologi", "Desainer Interior", "System Analyst", "Fotografer Profesional"],
      'answer': "System Analyst"
    },
  ];

  void _checkAnswer(String selectedAnswer) {
    if (_currentQuestionIndex < _questions.length) {
      setState(() {
        _selectedAnswers.add(selectedAnswer);
        if (selectedAnswer == _questions[_currentQuestionIndex]['answer']) {
          _score++;
        }
        _currentQuestionIndex++;
      });

      if (_currentQuestionIndex >= _questions.length) {
        _showLoadingIndicator();
        Future.delayed(Duration(milliseconds: 500), () {
          Navigator.pop(context);
          _showResult();
        });
      }
    }
  }

  void _showLoadingIndicator() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        content: Row(
          children: [
            CircularProgressIndicator(),
            SizedBox(width: 20),
            Text("Menghitung skor..."),
          ],
        ),
      ),
    );
  }

  void _showResult() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Kuis Selesai!", textAlign: TextAlign.center),
        content: SingleChildScrollView(
          child: Column(
            children: [
              Text(
                "Skor Anda: $_score dari ${_questions.length}",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              Column(
                children: List.generate(_questions.length, (index) {
                  String selected = _selectedAnswers.length > index ? _selectedAnswers[index] : "Tidak Dijawab";
                  bool isCorrect = selected == _questions[index]['answer'];
                  return Container(
                    margin: EdgeInsets.symmetric(vertical: 6),
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isCorrect ? Colors.green[100] : Colors.red[100],
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 4,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "${index + 1}. ${_questions[index]['question']}",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 5),
                        Text("Jawaban Anda: $selected"),
                        Text("Jawaban Benar: ${_questions[index]['answer']}"),
                      ],
                    ),
                  );
                }),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text("Kembali ke Beranda"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    var currentQ = _questions[_currentQuestionIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text("Soal ${_currentQuestionIndex + 1}"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  currentQ['question'],
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            SizedBox(height: 20),
            ...currentQ['options'].map<Widget>((option) {
              return Container(
                width: double.infinity,
                margin: EdgeInsets.symmetric(vertical: 6),
                child: ElevatedButton(
                  onPressed: () => _checkAnswer(option),
                  child: Text(option),
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }
}
